package com.nhnacademy;

public interface HitInterface {
    default void hit(Bounded ball) {
    }
    
}
