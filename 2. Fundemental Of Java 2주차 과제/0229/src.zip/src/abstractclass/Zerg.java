package src.abstractclass;

public abstract class Zerg extends Unit {
    protected Zerg() {
        tribe = "Zerg";
    }
}