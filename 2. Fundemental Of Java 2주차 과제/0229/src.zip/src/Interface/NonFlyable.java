package src.Interface;

// 날 수 없는 유닛은 -> 날 수 있는 유닛을 공격할 수 없다.
public interface NonFlyable {
    
}