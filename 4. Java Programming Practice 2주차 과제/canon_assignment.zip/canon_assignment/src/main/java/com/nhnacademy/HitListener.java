package com.nhnacademy;

public interface HitListener {
    void hit(Bounded other);
}
