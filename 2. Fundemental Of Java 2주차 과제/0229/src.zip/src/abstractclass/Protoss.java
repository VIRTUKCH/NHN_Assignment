package src.abstractclass;

public abstract class Protoss extends Unit {
    protected Protoss() {
        tribe = "Protoss";
    }
}