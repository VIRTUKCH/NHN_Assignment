package com.nhnacademy;

public class Item {
    String id;
    String model;
    int hp;
    int offensePower;
    int defensePower;
    int moveSpeed;
    int attackSpeed;

    public Item(String id, String model, int hp, int offensePower, int defensePower, int moveSpeed, int attackSpeed) {
        this.id = id;
        this.model = model;
        this.hp = hp;
        this.offensePower = offensePower;
        this.defensePower = defensePower;
        this.moveSpeed = moveSpeed;
        this.attackSpeed = attackSpeed;
    }

    public String getId() {
        return this.id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getModel() {
        return this.model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public int getHp() {
        return this.hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    public int getOffensePower() {
        return this.offensePower;
    }

    public void setOffensePower(int offensePower) {
        this.offensePower = offensePower;
    }

    public int getDefensePower() {
        return this.defensePower;
    }

    public void setDefensePower(int defensePower) {
        this.defensePower = defensePower;
    }

    public int getMoveSpeed() {
        return this.moveSpeed;
    }

    public void setMoveSpeed(int moveSpeed) {
        this.moveSpeed = moveSpeed;
    }

    public int getAttackSpeed() {
        return this.attackSpeed;
    }

    public void setAttackSpeed(int attackSpeed) {
        this.attackSpeed = attackSpeed;
    }
}