package com.nhnacademy;

public interface StartedActionListener {
    public void action();
}
