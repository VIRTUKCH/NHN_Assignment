package com.nhnacademy;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class ChangedHistory {
    Logger logger = LogManager.getLogger();
}
