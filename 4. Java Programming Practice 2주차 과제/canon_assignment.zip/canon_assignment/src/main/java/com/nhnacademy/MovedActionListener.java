package com.nhnacademy;

public interface MovedActionListener {
    public void action();
}
