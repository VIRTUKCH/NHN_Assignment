package src.Interface;

// 공중 유닛을 공격할 수 있는 유닛은 -> 공중 유닛을 공격할 수 있다.
// 다 때릴 수 있다.
public interface FlyAttackable {

}