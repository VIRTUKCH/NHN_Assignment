package com.nhnacademy;

public interface Bounceable {

    public void bounce(Bounded other);
}
