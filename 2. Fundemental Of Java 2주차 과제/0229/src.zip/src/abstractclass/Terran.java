package src.abstractclass;

public abstract class Terran extends Unit {
    protected Terran() {
        tribe = "Terran";
    }
}