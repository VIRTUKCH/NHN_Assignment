package src.Exception;

public class UnAttackableUnitException extends Exception {
    public UnAttackableUnitException(String message) { 
        super(message);
    }
}