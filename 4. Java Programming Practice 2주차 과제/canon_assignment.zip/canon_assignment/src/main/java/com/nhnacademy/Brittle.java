package com.nhnacademy;

public interface Brittle {
}